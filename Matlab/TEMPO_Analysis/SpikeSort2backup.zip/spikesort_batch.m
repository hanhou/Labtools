function varargout = SpikeSort_Batch(varargin)
% SPIKESORT_BATCH Application M-file for SpikeSort_Batch.fig
%    FIG = SPIKESORT_BATCH launch SpikeSort_Batch GUI.
%    SPIKESORT_BATCH('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.0 18-Feb-2002 15:03:43

if nargin == 0  % LAUNCH GUI

	fig = openfig(mfilename,'reuse');

	% Use system color scheme for figure:
	set(fig,'Color',get(0,'defaultUicontrolBackgroundColor'));

	% Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);

	if nargout > 0
		varargout{1} = fig;
	end

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		if (nargout)
			[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
		else
			feval(varargin{:}); % FEVAL switchyard
		end
	catch
		disp(lasterr);
	end

end


%| ABOUT CALLBACKS:
%| GUIDE automatically appends subfunction prototypes to this file, and 
%| sets objects' callback properties to call them through the FEVAL 
%| switchyard above. This comment describes that mechanism.
%|
%| Each callback subfunction declaration has the following form:
%| <SUBFUNCTION_NAME>(H, EVENTDATA, HANDLES, VARARGIN)
%|
%| The subfunction name is composed using the object's Tag and the 
%| callback type separated by '_', e.g. 'slider2_Callback',
%| 'figure1_CloseRequestFcn', 'axis1_ButtondownFcn'.
%|
%| H is the callback object's handle (obtained using GCBO).
%|
%| EVENTDATA is empty, but reserved for future use.
%|
%| HANDLES is a structure containing handles of components in GUI using
%| tags as fieldnames, e.g. handles.figure1, handles.slider2. This
%| structure is created at GUI startup using GUIHANDLES and stored in
%| the figure's application data using GUIDATA. A copy of the structure
%| is passed to each callback.  You can store additional information in
%| this structure at GUI startup, and you can change the structure
%| during callbacks.  Call guidata(h, handles) after changing your
%| copy to replace the stored original so that subsequent callbacks see
%| the updates. Type "help guihandles" and "help guidata" for more
%| information.
%|
%| VARARGIN contains any extra arguments you have passed to the
%| callback. Specify the extra arguments by editing the callback
%| property in the inspector. By default, GUIDE sets the property to:
%| <MFILENAME>('<SUBFUNCTION_NAME>', gcbo, [], guidata(gcbo))
%| Add any extra arguments after the last argument, before the final
%| closing parenthesis.


% --------------------------------------------------------------------
function varargout = BatchFileEdit_Callback(h, eventdata, handles, varargin)


% ----------------------------------------------------------------------------
% Loads the batchfile into memory.
% ----------------------------------------------------------------------------
function varargout = LoadBatchButton_Callback(h, eventdata, handles, varargin)
    dfltDir = 'Z:/Data/Tempo/Batch Files';   % Default data directory
    dfltSuffix = '*.m';      % Default file type.
    cd(dfltDir);

    % Locate the batch file and check if anything was chosen.
    [batchFileName, batchPath] = uigetfile(dfltSuffix, 'Choose Batch File');
    if (batchFileName == 0)
        return;
    end
    
    set(handles.BatchFileEdit, 'String', [batchPath, batchFileName]);
    
    % Use textread to grab the path and filename of all files to be processed.
    [handles.filePath, handles.fileName] = textread([batchPath, batchFileName], '%s%s%*[^\n]', 'commentstyle', 'matlab');
    
    guidata(h, handles);



% --------------------------------------------------------------------
function varargout = StartButton_Callback(h, eventdata, handles, varargin)
    handles.usLevel = str2num(get(handles.UpperSLevel, 'String'));
    handles.lsLevel = str2num(get(handles.LowerSLevel, 'String'));
    handles.wData = 0;
    
    % Make sure these variables are clear.
    clear global CHAN1;
    clear global CHAN2;
    clear global CHAN32;
    clear global spsData;
    
    % Make sure the user selects an upper and/or lower threshold.
    if (get(handles.UpperThreshCheck, 'Value') == 0 & get(handles.LowerThreshCheck, 'Value') == 0)
        errordlg('Please select a threshold!', 'Error');
        return;
    end
    
    % Clear the FileList.
    set(handles.FileList, 'Value', 1);
    set(handles.FileList, 'String', '');
    
    for (i = 1:length(handles.fileName))
        fileList = get(handles.FileList, 'String');
        listLength = length(fileList);
        
        % Generate .smr filpath and filename.
        x = find(handles.filePath{i} == '\');
        handles.smrFilePath = ['Z:/Data/CED/', handles.filePath{i}(x(3)+1 : x(4) - 1), '/'];
        handles.smrFileName = [handles.fileName{i}(1:length(handles.fileName{i}) - 4), '.smr'];
        
        % Add the file being processed to the list.
        fileList{listLength + 1} = ['Analyzing -- ', handles.smrFilePath, handles.smrFileName, ' ........... '];
        set(handles.FileList, 'String', fileList);
        set(handles.FileList, 'Value', listLength + 1);
        
        % Call all the processing functions.
        disp('Loading spike data');
        handles = LoadSpikeData(handles, i);
        
        % Go to the next file if there was a problem opening the file.
        if (handles.spike2file < 0)
            % Show that the file was bad.
            fileList{listLength + 1} = [fileList{listLength + 1}, 'Bad File'];
            % Update the file list.
            set(handles.FileList, 'String', fileList);
            set(handles.FileList, 'Value', listLength + 1);
            continue;
        end
        
        disp('Finding thresholds');
        handles = FindThresholds(handles);
        disp('Sorting data');
        handles = SortData(handles);
        
        % Close the .smr file.
        cedfunction('SonCloseFile', handles.spike2file);
        
        % Export spsData
        global spsData;
        wdata = handles.wData;
        eval(['save ', handles.smrFilePath, '/SortedSpikes/', handles.smrFileName(1:length(handles.smrFileName) - 3), 'mat', ' spsData wdata']);
        
                
        % Clear all data channels.
        clear global CHAN1;
        clear global CHAN32;
        clear global spsData;
        
        % Show that the file is done being processed.
        fileList{listLength + 1} = [fileList{listLength + 1}, 'Finished'];
        
        % Update the file list.
        set(handles.FileList, 'String', fileList);
        set(handles.FileList, 'Value', listLength + 1);
    end
    
    % Indicate that everything is finished.
    fl = get(handles.FileList, 'String');
    fl{length(fl) + 1} = 'Done';
    set(handles.FileList, 'String', fl);
    set(handles.FileList, 'Value', length(fl));
    
    guidata(h, handles);
    
    
    
% ----------------------------------------------------------------------------------
%   Sorts the data and exports the sorted spikes out to a file.
% ----------------------------------------------------------------------------------
function handles = SortData(handles)
    clear global spsData;
    global CHAN1 CHAN2 CHAN32 spsData;
    index = [];
    
    % Find all the stimulus start codes that resulted in a successful trial.
    for (i = 1:length(CHAN32))
        % If we find a stimuls start code, then we look to see if we find
        % a success code before we get to another start code.
        if(CHAN32(i).mvals == 4)
            j = i + 1;
            while (j <= length(CHAN32) & CHAN32(j).mvals ~= 4)
                if (CHAN32(j).mvals == 12)
                    index = [index, i];
                    break;
                else
                    j = j + 1;
                end
            end
            i = j;
        end
    end
    
    % Stuff the spsData struct array with information about each successfull trial.
    handles.spikeSet = 1;
    spsData(handles.spikeSet).sampleRate = 25000;
    spsData(handles.spikeSet).prebuffer = round(str2num(handles.PreEventBuffer) * 25000);
    spsData(handles.spikeSet).postbuffer = round(str2num(handles.PostEventBuffer) * 25000);
    if (get(handles.UpperThreshCheck, 'Value'))
        spsData(handles.spikeSet).upperThreshold = handles.utValue / 5.0 * (2^15 - 1);
    else
        spsData(handles.spikeSet).upperThreshold = NaN;
    end
    if (get(handles.LowerThreshCheck, 'Value'))
        spsData(handles.spikeSet).lowerThreshold = handles.ltValue / 5.0 * (2^15 - 1);
    else
        spsData(handles.spikeSet).lowerThreshold = NaN;
    end
    
    for (i = 1:length(index))
        disp(['Processing event ', num2str(i)]);
        
        % This is basically descriptive data about the spike area analyzed.
        spsData(handles.spikeSet).spikeInfo(i).startCodeTime = round(CHAN32(index(i)).mark / handles.chand);
         
        spsData(handles.spikeSet).spikeInfo(i).startTime = spsData(handles.spikeSet).spikeInfo(i).startCodeTime - spsData(handles.spikeSet).prebuffer + 1;
        spsData(handles.spikeSet).spikeInfo(i).endTime = spsData(handles.spikeSet).spikeInfo(i).startCodeTime + spsData(handles.spikeSet).postbuffer;
        spsData(handles.spikeSet).spikeInfo(i).wSpikeTimes = [];
        
        % Make sure that the start and end times are within the range of the ADC
        % channel times.
        if (spsData(handles.spikeSet).spikeInfo(i).startTime < 1)
            spsData(handles.spikeSet).spikeInfo(i).startTime = 1;
        end
        if (spsData(handles.spikeSet).spikeInfo(i).endTime > length(CHAN1))
            spsData(handles.spikeSet).spikeInfo(i).endTime = length(CHAN1);
        end
        
        % Find all the threshold discontinuities in the ADC data.
        upperSpikeIndex = []; lowerSpikeIndex = [];
        if (get(handles.UpperThreshCheck, 'Value'))
            upperSpikeIndex = find(CHAN1(spsData(handles.spikeSet).spikeInfo(i).startTime : spsData(handles.spikeSet).spikeInfo(i).endTime) >= spsData(handles.spikeSet).upperThreshold) + spsData(handles.spikeSet).spikeInfo(i).startTime - 1;
        end
        if (get(handles.LowerThreshCheck, 'Value'))
            lowerSpikeIndex = find(CHAN1(spsData(handles.spikeSet).spikeInfo(i).startTime : spsData(handles.spikeSet).spikeInfo(i).endTime) <= spsData(handles.spikeSet).lowerThreshold) + spsData(handles.spikeSet).spikeInfo(i).startTime - 1;
        end
        
        % Find all the upper threshold spike times.
        if (~isempty(upperSpikeIndex) & get(handles.UpperThreshCheck, 'Value'))
            shiftedData = diff(upperSpikeIndex);
            shiftedData = [2, shiftedData];
            shiftIndex = find(shiftedData > 1);
        
            % Now we actually go through all upper threshold spike areas and find the max.
            for (j = 1:length(shiftIndex))
                % The last element is treated differently
                if (j ~= length(shiftIndex))
                    x = [shiftIndex(j) : shiftIndex(j+1) - 1];
                    y = upperSpikeIndex(x);
                    [n, t] = max(CHAN1(y));
                    spsData(handles.spikeSet).spikeInfo(i).pSpikeTimes(j) = upperSpikeIndex(t + shiftIndex(j) - 1);
                else
                    x = [shiftIndex(j):length(upperSpikeIndex)];
                    y = upperSpikeIndex(x);
                    [n, t] = max(CHAN1(y));
                    spsData(handles.spikeSet).spikeInfo(i).pSpikeTimes(j) = upperSpikeIndex(t + shiftIndex(j) - 1);
                end
            end
        else
            spsData(handles.spikeSet).spikeInfo(i).pSpikeTimes = [];
        end % End if (~isempty(upperSpikeIndex))
        
        % Find all the lower threshold spike times.
        if (~isempty(lowerSpikeIndex) & get(handles.LowerThreshCheck, 'Value'))
            shiftedData = diff(lowerSpikeIndex);
            shiftedData = [2, shiftedData];
            shiftIndex = find(shiftedData > 1);
        
            % Now we actually go through all upper threshold spike areas and find the max.
            for (j = 1:length(shiftIndex))
                % The last element is treated differently
                if (j ~= length(shiftIndex))
                    x = [shiftIndex(j) : shiftIndex(j+1) - 1];
                    y = lowerSpikeIndex(x);
                    [n, t] = min(CHAN1(y));
                    spsData(handles.spikeSet).spikeInfo(i).nSpikeTimes(j) = lowerSpikeIndex(t + shiftIndex(j) - 1);
                else
                    x = [shiftIndex(j):length(lowerSpikeIndex)];
                    y = lowerSpikeIndex(x);
                    [n, t] = min(CHAN1(y));
                    spsData(handles.spikeSet).spikeInfo(i).nSpikeTimes(j) = lowerSpikeIndex(t + shiftIndex(j) - 1);
                end
            end
        else
            spsData(handles.spikeSet).spikeInfo(i).nSpikeTimes = [];
        end % End if (~isempty(lowerSpikeIndex))
    end % End for (i = 1:length(index))
    
    % Store all the window discriminated spikes only if it was selected to be loaded.
    if (handles.maxTime2 > 0)
        eTimes = round([CHAN2(1:length(CHAN2)).time] / handles.chand);
        
        % Set common data about the channel being read in.
        spsData(handles.spikeSet + 1).chanNumber = 2;
        spsData(handles.spikeSet + 1).prebuffer = round(str2num(handles.PreEventBuffer) * 25000);
        spsData(handles.spikeSet + 1).postbuffer = round(str2num(handles.PostEventBuffer) * 25000);
        
        for (i = 1:length(index))
            disp(['Processing Window Discriminator Event ', num2str(i)]);
            % Set data in spsData.
            spsData(handles.spikeSet + 1).spikeInfo(i).startCodeTime = round(CHAN32(index(i)).mark / handles.chand);
            spsData(handles.spikeSet + 1).spikeInfo(i).startTime = spsData(handles.spikeSet + 1).spikeInfo(i).startCodeTime - spsData(handles.spikeSet + 1).prebuffer + 1;
            spsData(handles.spikeSet + 1).spikeInfo(i).endTime = spsData(handles.spikeSet + 1).spikeInfo(i).startCodeTime + spsData(handles.spikeSet + 1).postbuffer;
            spsData(handles.spikeSet + 1).spikeInfo(i).pSpikeTimes = [];
            spsData(handles.spikeSet + 1).spikeInfo(i).nSpikeTimes = [];
            spsData(handles.spikeSet + 1).spikeInfo(i).wSpikeTimes = eTimes(find(eTimes >= spsData(handles.spikeSet).spikeInfo(i).startTime & eTimes <= spsData(handles.spikeSet).spikeInfo(i).endTime));
        end
    end
    
    return;
    
    
% ----------------------------------------------------------------------------------
%   Finds the treshold voltage values specified in the batch file.
% ----------------------------------------------------------------------------------
function handles = FindThresholds(handles)
    codeTimes = FindSpontaneousCodeTimes(handles);
    
    % Find upper threshold level.
    if (get(handles.UpperThreshCheck, 'Value'))
        handles.utValue = FindThreshold(codeTimes, 2, handles, handles.rangeMax / 2, handles.usLevel, 1);
        disp('Upperthreshold found');
    end
    
    % Find lower threshold level.
    if (get(handles.LowerThreshCheck, 'Value'))
        handles.ltValue = FindThreshold(codeTimes, 2, handles, handles.rangeMax / 2, handles.lsLevel, -1);
        disp('Lowerthreshold found');
    end
    
    return;
    
    
    
% ----------------------------------------------------------------------------
%   Loads spike data from a file and processes it.
% ----------------------------------------------------------------------------
function handles = LoadSpikeData(handles, dumdex)    
    % Look at the corresponding .htb file and load the pre/post buffer times.
    asdf = [handles.filePath{dumdex}, handles.fileName{dumdex}];
    fid = htbOpen(asdf);     % Open the htb file.
    ndbs = htbCount(fid);    % Find out the # of databases it holds.
    % Find the Events database and get the times.
    for (i = 1:ndbs)
        hd = htbGetHd(fid, i);   % Get the database header.
        
        if (strcmp(hd.title, 'Events'))
            hertz = hd.speed_units / hd.speed;    % see p366 in TEMPO v9 manual
   	        binwidth = (hd.skip + 1) / hertz;
	        epoch_start = hd.offset * binwidth;
   	        epoch_period = hd.period * binwidth;
            handles.PreEventBuffer = num2str(epoch_start);
            handles.PostEventBuffer = num2str(-epoch_start + epoch_period);
            break;
        end
    end
    htbClose(fid);
    
    % Open up the Spike2 data file.
    handles.spike2file = cedfunction('SonOpenOldFile', [handles.smrFilePath, handles.smrFileName], 1);
    if (handles.spike2file >= 0)
        disp('File opened successfully');
    else
        disp('Could not open smr file.');
        return;
    end
    
    % Load ADC channel 1 into memory.
    global CHAN1;
    handles.maxTime1 = cedfunction('SonChanMaxTime', handles.spike2file, 0);
    handles.chand = cedfunction('SonChanDivide', handles.spike2file, 0);
    numpts = cedfunction('SonGetNumADCPts', handles.spike2file, 0, 10000, 0, handles.maxTime1, handles.chand);
    [CHAN1, num] = cedfunction('SonGetAllADCData', handles.spike2file, 0, numpts, 0, handles.maxTime1, handles.chand);
    
    % Load ADC Channel 2 into memory (Window Discriminator).
    global CHAN2;
    handles.maxTime2 = cedfunction('SonChanMaxTime', handles.spike2file, 1);
    if (handles.maxTime2 > 0)
        [num, CHAN2] = cedfunction('SonGetEventData', handles.spike2file, 1, 1000000, 0, handles.maxTime2);
        handles.wData = 1;
    else
        disp('No Channel 2');
        handles.maxTime2 = 0;
        handles.wData = 0;
    end
    
    % Load Event channel 32 into memory.
    global CHAN32;
    handles.maxTime32 = cedfunction('SonChanMaxTime', handles.spike2file, 31);
    [num, CHAN32] = cedfunction('SonGetMarkData', handles.spike2file, 31, 1000000, 0, handles.maxTime32);
    
    % Determine max and min range values for the voltages.
    maxVoltage = abs(double(max(CHAN1)) / (2^15 - 1) * 5);
    minVoltage = abs(double(min(CHAN1)) / (2^15 - 1) * 5);
    handles.rangeMax = round(max([maxVoltage, minVoltage])) + .5;
    
    % Close the open spike file.
    cedfunction('SonCloseFile', handles.spike2file);
    
    return;
    
    
% --------------------------------------------------------------------------
%   Finds the times that are necessary to calculate the spontaneous level.
% --------------------------------------------------------------------------
function codeTimes = FindSpontaneousCodeTimes(handles)
    global CHAN32;
    tCount = 1;
    
    % Find all time periods between a fix code and a stim start code.
    for (i = 1:length(CHAN32))
        % If we find a fixate code, record the start and stop times.
        if(CHAN32(i).mvals == 3)
            j = i + 1;
            while (j <= length(CHAN32) & CHAN32(j).mvals ~= 3)
                if (CHAN32(j).mvals == 4)
                    codeTimes(tCount).sTime = round(CHAN32(i).mark / handles.chand);
                    codeTimes(tCount).eTime = round(CHAN32(j).mark / handles.chand);
                    tCount = tCount + 1;
                    break;
                else
                    j = j + 1;
                end
            end
            i = j;
        end
    end
    
    return;
    
    
    
% --------------------------------------------------------------------------
%   This is a recursive function that tries to find a threshold value
%   that closely matches a specified spontaneity value.  The polarity
%   parameter lets you choose whether you're looking at positive or
%   negative numbers.
% --------------------------------------------------------------------------
function threshValue = FindThreshold(cTimes, rangeDivide, handles, tValue, spontValue, polarity)
    global CHAN1;
    totalTime = 0;
    totalSpikes = 0;
    
    % Go through each set of code times and look for spikes above the threshold.
    for (i = 1:length(cTimes))
        spikeIndex = find(double(CHAN1(cTimes(i).sTime : cTimes(i).eTime)) * polarity > (tValue / 5.0 * (2^15 - 1)));
        totalTime = totalTime + cTimes(i).eTime - cTimes(i).sTime;
        
        % If spikeIndex is empty then go to the next iteration.
        if (isempty(spikeIndex))
            continue;
        end
        shiftedData = diff(spikeIndex);
        
        % Count the number of spikes found in this time segment.
        totalSpikes = totalSpikes + length(find(shiftedData > 1)) + 1;
    end  
    
    totalTime = totalTime / 25000;  % Convert 'totalTime' into seconds.
    spikeAverage = round(totalSpikes / totalTime);
    
    % If the spikeAverage is equal to the spontValue, then we can return the ideal
    % threshold.  Otherwise, keep searching.
    % If our spike average is < spontValue, then we need to increase our tValue.
    % If it's >, then we need to decrease tValue.
    if (spikeAverage == spontValue)
        threshValue = tValue;
    elseif (spikeAverage < spontValue)
        threshValue = FindThreshold(cTimes, rangeDivide + 1, handles, tValue - (handles.rangeMax / 2^rangeDivide), spontValue, polarity);
    else
        threshValue = FindThreshold(cTimes, rangeDivide + 1, handles, tValue + (handles.rangeMax / 2^rangeDivide), spontValue, polarity);
    end
    
    return;


% --------------------------------------------------------------------
function varargout = UpperThreshCheck_Callback(h, eventdata, handles, varargin)
function varargout = LowerThreshCheck_Callback(h, eventdata, handles, varargin)
