function[]=SONVersion()
title='MATLAB SON Library';
st=sprintf('\nMATLAB SON Library: Malcolm Lidierth, King%cs College London 15.12.03\nVersion:1.02\n\nSON Filing system Copyright %c Cambridge Electronic Design 1988-2001\nVersion 6.0',39,169);

h=(msgbox(st,title,'modal'));
