% Contains all 54 MST cells.  Additional cells that were rejected for poor isolation are commented out.
Z:\Data\MOOG\Barracuda\Raw\ m9c106r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c107r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c110r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c112r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c113r6.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c119r6.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c121r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c123r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c128r4.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c131r4.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c141r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c143r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c145r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c150r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c151r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c155r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c157r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c163r6.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c169r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c171r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c175r6.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c180r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c186r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c192r5_6.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c199r6.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c208r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c209r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
% Z:\Data\MOOG\Barracuda\Raw\ m9c211r6_7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING
Z:\Data\MOOG\Barracuda\Raw\ m9c212r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c215r4.htb 'MPReviews' -1 -1 4 0 5 0 1 1  
Z:\Data\MOOG\Barracuda\Raw\ m9c237r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c240r6.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c241r7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c262r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c289r9.htb 'MPReviews' -1 -1 4 0 5 0 1 1
% Ovid MST
Z:\Data\MOOG\Ovid\Raw\ m15c12r5_6.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c20r4_5a.htb 'MPReviews' -1 -1 4 0 5 0 1 1 % Missing 1 rep somehow, using clipped file
Z:\Data\MOOG\Ovid\Raw\ m15c63r4_5.htb 'MPReviews' -1 -1 4 0 5 0 1 1
% Z:\Data\MOOG\Ovid\Raw\ m15c66r4_5_4_7.htb 'MPReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING
Z:\Data\MOOG\Ovid\Raw\ m15c70r4.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c72r6.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c73r5.htb 'MPReviews' -1 -1 4 0 5 0 1
Z:\Data\MOOG\Ovid\Raw\ m15c74r5.htb 'MPReviews' -1 -1 4 0 5 0 1 1
% Z:\Data\MOOG\Ovid\Raw\ m15c82r4.htb 'MPReviews' -1 -1 4 0 5 0 1 % Missing
Z:\Data\MOOG\Ovid\Raw\ m15c83r6.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c85r4_5_6.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c86r4_5.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c88r4_5.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c92r5_6.htb 'MPReviews' -1 -1 4 0 5 0 1 1 
% Z:\Data\MOOG\Ovid\Raw\ m15c96r6_7_8_9.htb 'MPReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING
Z:\Data\MOOG\Ovid\Raw\ m15c97r4_5.htb 'MPReviews' -1 -1 4 0 5 0 1 1
% Z:\Data\MOOG\Ovid\Raw\ m15c98r4_5.htb 'MPReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING
Z:\Data\MOOG\Ovid\Raw\ m15c99r4_5_6.htb 'MPReviews' -1 -1 4 0 5 0 1 1
% Z:\Data\MOOG\Ovid\Raw\ m15c105r5_6_7_8.htb 'MPReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING
Z:\Data\MOOG\Ovid\Raw\ m15c107r4_5.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c109r9_10.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c110r8_9.htb 'MPReviews' -1 -1 4 0 5 0 1 1
% Z:\Data\MOOG\Ovid\Raw\ m15c111r8_9.htb 'MPReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING
Z:\Data\MOOG\Ovid\Raw\ m15c112r6_7.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c114r4_5.htb 'MPReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c116r6_7.htb 'MPReviews' -1 -1 4 0 5 0 1 1