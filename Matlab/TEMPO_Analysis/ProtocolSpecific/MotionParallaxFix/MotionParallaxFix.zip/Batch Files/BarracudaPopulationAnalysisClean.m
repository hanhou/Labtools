% Contains all 144 MT cells for both monkeys (despite the fact it is called BarracudaPopulationAnalysisClean)
% Additional cells that were rejected for poor isolation are commented out.  
% Some cells were recorded twice using a subtle fixation point shift to improve 
% pursuit gain; such duplicates are also commented out.
%
% Barracuda Data
Z:\Data\MOOG\Barracuda\Raw\ m9c103r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c105r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c108r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c109r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c111r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c114r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c115r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c117r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c124r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c129r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c132r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c133r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c134r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c135r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c136r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c138r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c140r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c142r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c144r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c146r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c147r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c148r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c156r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c158r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c164r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c166r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c167r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c170r8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c172r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c173r8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c176r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c177r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c178r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c179r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c183r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c184r3.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c193r5_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c196r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Barracuda\Raw\ m9c197r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Barracuda\Raw\ m9c201r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c202r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c203r6_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c204r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c205r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c207r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c210r8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c217r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c219r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c221r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1   
Z:\Data\MOOG\Barracuda\Raw\ m9c235r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c236r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c242r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c243r7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c244r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c245r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c247r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c248r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1  
Z:\Data\MOOG\Barracuda\Raw\ m9c252r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c253r9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1  
Z:\Data\MOOG\Barracuda\Raw\ m9c254r7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c255r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c257r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c261r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c263r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c264r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c265r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c267r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c268r6_9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c270r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c272r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c273r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c275r3_4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c276r7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c277r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c278r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c279r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c282r5_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c283r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c284r8_9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c285r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
Z:\Data\MOOG\Barracuda\Raw\ m9c286r6_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 
% Z:\Data\MOOG\Barracuda\Raw\ m9c288r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING
Z:\Data\MOOG\Barracuda\Raw\ m9c290r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
% Ovid MT (w/ duplicates!)
Z:\Data\MOOG\Ovid\Raw\ m15c2r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c3r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c4r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c5r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c6r9_10.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c7r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c8r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c10r8_9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c11r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c15r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c17r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c18r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % 2 trials of 4th rep #18 
Z:\Data\MOOG\Ovid\Raw\ m15c22r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c24r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c25r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c26r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
% Z:\Data\MOOG\Ovid\Raw\ m15c27r6_7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING 
Z:\Data\MOOG\Ovid\Raw\ m15c28r6_7_9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c29r5_6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c30r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c31r6_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c32r6_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 95 #32r6 and 32r8
% Z:\Data\MOOG\Ovid\Raw\ m15c32r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 1 #32r7
Z:\Data\MOOG\Ovid\Raw\ m15c33r5_8_10.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 95
% Z:\Data\MOOG\Ovid\Raw\ m15c33r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 1
Z:\Data\MOOG\Ovid\Raw\ m15c34r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 95 #34r6 first rep, else PG 1
Z:\Data\MOOG\Ovid\Raw\ m15c36r6_7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c38r5_6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c39r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c40r5_6_7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c41r8_9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c42r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c43r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % shutters not working (conflict case) #43
Z:\Data\MOOG\Ovid\Raw\ m15c44r5_6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c45r5_6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % Need to hand combine this one because r5 has junk in it
Z:\Data\MOOG\Ovid\Raw\ m15c46r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c49r2.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c51r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c52r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c53r4_6_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 95
% Z:\Data\MOOG\Ovid\Raw\ m15c53r5_7_9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 1
Z:\Data\MOOG\Ovid\Raw\ m15c54r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c55r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 95
% Z:\Data\MOOG\Ovid\Raw\ m15c55r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 1
Z:\Data\MOOG\Ovid\Raw\ m15c56r7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % Incomplete cell property data for #56
Z:\Data\MOOG\Ovid\Raw\ m15c57r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 95
% Z:\Data\MOOG\Ovid\Raw\ m15c57r7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % PG 1
Z:\Data\MOOG\Ovid\Raw\ m15c58r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c59r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c60r4_5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c62r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c64r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c67r5_6_7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 95
% Z:\Data\MOOG\Ovid\Raw\ m15c67r9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 1
Z:\Data\MOOG\Ovid\Raw\ m15c69r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 95
% Z:\Data\MOOG\Ovid\Raw\ m15c69r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 1
Z:\Data\MOOG\Ovid\Raw\ m15c71r4.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c77r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 95
% Z:\Data\MOOG\Ovid\Raw\ m15c77r6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 1
Z:\Data\MOOG\Ovid\Raw\ m15c78r5_6.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 98
Z:\Data\MOOG\Ovid\Raw\ m15c81r5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 98
Z:\Data\MOOG\Ovid\Raw\ m15c89r4_5.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 98
Z:\Data\MOOG\Ovid\Raw\ m15c90r5_7_8_9.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 97
Z:\Data\MOOG\Ovid\Raw\ m15c91r4_5_6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 %PG 95
Z:\Data\MOOG\Ovid\Raw\ m15c94r6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c95r6_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
% Z:\Data\MOOG\Ovid\Raw\ m15c100r5_7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1 % REMOVED MU or RINGING
Z:\Data\MOOG\Ovid\Raw\ m15c101r5_7_8_9_8b_10 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c102r6_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c103r4_6_7_8.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c104r4_6_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1
Z:\Data\MOOG\Ovid\Raw\ m15c106r5_7.htb 'MPPursuitReviews' -1 -1 4 0 5 0 1 1