﻿$(document).ready(function(){
  $('li.expandable > a').click(function() {
    $(this).parent().toggleClass("collapsed").toggleClass("expanded"); return false;
  });	
});


//Bug fixes for IE11
(function() {
    // Functions to create xhrs
    function createStandardXHR() {
        try {
            return new window.XMLHttpRequest();
        } catch (e) {
        }
    }

    function createActiveXHR() {
        try {
            return new window.ActiveXObject("Microsoft.XMLHTTP");
        } catch (e) {
        }
    }

    // Create the request object
    jQuery.ajaxSettings.xhr = window.ActiveXObject !== undefined ?
        /* Microsoft failed to properly
         * implement the XMLHttpRequest in IE7
         * (can't request local files),
         * so we use the ActiveXObject when it is available
         * Additionally XMLHttpRequest can be disabled in
         * IE7/IE8 so
         * we need a fallback.
         */
        function () {
            return !this.isLocal &&
                createStandardXHR() || createActiveXHR();
        } :
        // For all other browsers, use the standard
        // XMLHttpRequest object
        createStandardXHR;

    //Detect if IE 11
    if (Object.hasOwnProperty.call(window, "ActiveXObject") && !window.ActiveXObject) {
        jQuery.browser.msie = true;
        jQuery.browser.version = "11.0";
    }
})();
